<?php

namespace TechChallenge\Domain\Category\Exceptions;

use TechChallenge\Domain\Shared\Exceptions\DefaultException;

class CategoryException extends DefaultException
{
}
