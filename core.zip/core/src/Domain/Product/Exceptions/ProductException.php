<?php

namespace TechChallenge\Domain\Product\Exceptions;

use TechChallenge\Domain\Shared\Exceptions\DefaultException;

class ProductException extends DefaultException
{
}
