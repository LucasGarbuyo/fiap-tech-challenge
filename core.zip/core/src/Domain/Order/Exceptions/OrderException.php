<?php

namespace TechChallenge\Domain\Order\Exceptions;

use TechChallenge\Domain\Shared\Exceptions\DefaultException;

class OrderException extends DefaultException
{
}
