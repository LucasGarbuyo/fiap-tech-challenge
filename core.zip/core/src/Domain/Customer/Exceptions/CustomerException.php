<?php

namespace TechChallenge\Domain\Customer\Exceptions;

use TechChallenge\Domain\Shared\Exceptions\DefaultException;

class CustomerException extends DefaultException
{
}
