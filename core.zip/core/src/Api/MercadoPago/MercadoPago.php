<?php

namespace TechChallenge\Api\MercadoPago;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use MercadoPago\Client\CardToken\CardTokenClient;
use MercadoPago\Exceptions\MPApiException;
use MercadoPago\Client\Common\RequestOptions;

class MercadoPago extends Controller
{
  public function update(Request $request)
  {

    // Log the request for debugging
    Log::info('Mercado Pago Webhook received:', [$request->all()]);

    $cardToken = $this->processPayment($request);

    dd($cardToken->id);
  }

  public function processPayment(Request $request)
  {
    // Configura o SDK do MercadoPago com seu token de acesso
    $accessToken = config('services.mercadopago.access_token');
    $requestOptions = new RequestOptions();
    $requestOptions->setAccessToken($accessToken);

    // Dados do cartão enviados pela solicitação
    $data = [
      'card_number' => $request->input('card_number'),
      'expiration_month' => $request->input('expiration_month'),
      'expiration_year' => $request->input('expiration_year'),
      'security_code' => $request->input('security_code'),
      'cardholder' => [
        'name' => $request->input('cardholder_name'),
        'identification' => [
          'type' => $request->input('identification_type'),
          'number' => $request->input('identification_number'),
        ],
      ],
    ];

    try {
      // Cria o cliente de token de cartão
      $cardTokenClient = new CardTokenClient();

      // Envia a requisição para gerar o token de cartão
      $cardToken = $cardTokenClient->create($data, $requestOptions);

      // Retorna o token de cartão gerado
      return $cardToken; //response()->json($cardToken);
    } catch (MPApiException $e) {
      // Captura a resposta de erro
      $errorResponse = json_decode($e->getMessage(), true);
      return response()->json(['error' => $errorResponse], $e->getCode());
    } catch (\Exception $e) {
      // Trata outras exceções
      return response()->json(['error' => $e->getMessage()], 500);
    }
  }
}
